This module extends the functionality of point of sale to hide cost and margin on
product detail.
