* Sebastien Alix <sebastien.alix@camptocamp.com>
* Holger Brunn <hbrunn@therp.nl>
* Holden Rehg <holdenrehg@gmail.com>
* Eric Lembregts <eric@lembregts.eu>
* Pieter Paulussen <pieter.paulussen@me.com>
* Alan Ramos <alan.ramos@jarsa.com.mx>
* Stefan Rijnhart <stefan@opener.amsterdam>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* Hardik Suthar <hsuthar@opensourceintegrators.com>
* Kitti U. <kittiu@ecosoft.co.th>
* Bogdan Valentin Gabor <valentin.gabor@bt-group.com>
