<img alt="Odoo by pronexo.com" src="https://raw.githubusercontent.com/pronexo-argentina/odoo_pos_addons/14.0/pos_l10n_ar_identification/static/description/ProNexo_Logo2021.png" />
pronexo.com - https://www.pronexo.com

Odoo V14

This module adds fields from Python models to POS models, and allows to:

Add or edit customer fields like "Responsability Type", "Document Type".

Use the above fields for other stuff like eInvoices.
=====================
POS Fuelds

Configuration
=============
* No additional configurations needed

Créditos
========
Desde Odoo 9 la Ing. Gabriela Rivero mantiene y colabora con el POS de Odoo. 

Company
-------
* `Pronexo <https://pronexo.com/>`__



Contacts
--------
* Mail Contact : info@pronexo.com
* Website : https://pronexo.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.
