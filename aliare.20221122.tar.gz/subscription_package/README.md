Subscription Package for Community
==================================
* Subscription Package for Odoo 15 community edition

Installation
============
 - www.odoo.com/documentation/15.0/setup/install.html
 - Install our custom addon

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Credits
--------
* Developer: Amal Prasad @ Cybrosys,
             Alakananda @ Cybrosys

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__